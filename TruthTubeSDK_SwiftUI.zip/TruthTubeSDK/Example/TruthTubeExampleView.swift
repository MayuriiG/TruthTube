import SwiftUI
import TruthTubeSDK

struct TruthTubeExampleView: View {
    @State private var videoTitle = ""
    @State private var result: TruthTubeAnalysisResult?

    var body: some View {
        VStack(spacing: 20) {
            Text("TruthTube")
                .font(.largeTitle.bold())

            TextField("Video title", text: $videoTitle)
                .textFieldStyle(.roundedBorder)

            Button("🤖 Analyze") {
                result = TruthTubeAnalyzer.shared.analyze(title: videoTitle)
            }

            if let result {
                Text(result.symbol).font(.system(size: 52))
                Text(result.label).font(.headline)
                if let reason = result.reason { Text(reason) }
                if let recommendation = result.recommendation { Text(recommendation) }
            }
        }
        .padding()
    }
}
