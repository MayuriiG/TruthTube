# TruthTubeSDK

A native Swift Package converted from the supplied TruthTube browser extension.

## What it does
TruthTubeSDK analyzes a video title using the same keyword-based logic as the original extension:
- Red: potential fake/clickbait keywords
- Yellow: possible AI-generated-content keywords
- Green: no obvious warning

Important: This is heuristic title analysis. It does not prove whether a video is fake or AI-generated.

## Add to Xcode (local package)
1. Unzip `TruthTubeSDK.zip`.
2. In Xcode open your iOS project.
3. Choose **File > Add Package Dependencies...**
4. Choose **Add Local...** and select the `TruthTubeSDK` folder.
5. Add the `TruthTubeSDK` library product to your app target.
6. Use `import TruthTubeSDK`.

## Basic usage

```swift
import TruthTubeSDK

let result = TruthTubeAnalyzer.shared.analyze(
    title: "This AI video is 100% real"
)

print(result.label)
print(result.formattedMessage)
```

## SwiftUI example

```swift
import SwiftUI
import TruthTubeSDK

struct ContentView: View {
    @State private var title = ""
    @State private var result: TruthTubeAnalysisResult?

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                TextField("Enter YouTube video title", text: $title)
                    .textFieldStyle(.roundedBorder)

                Button("Analyze Video Title") {
                    result = TruthTubeAnalyzer.shared.analyze(title: title)
                }
                .buttonStyle(.borderedProminent)

                if let result {
                    Text(result.symbol)
                        .font(.system(size: 48))
                    Text(result.label)
                        .font(.headline)
                    Text(result.formattedMessage)
                }

                Spacer()
            }
            .padding()
            .navigationTitle("TruthTube")
        }
    }
}
```

## Note about YouTube
The original Chrome extension reads `document.title` directly from a YouTube webpage. A normal iOS app cannot inject a Chrome content script into the YouTube app. Pass a title obtained by your app into `analyze(title:)`. URL/API-based metadata fetching can be added separately.
