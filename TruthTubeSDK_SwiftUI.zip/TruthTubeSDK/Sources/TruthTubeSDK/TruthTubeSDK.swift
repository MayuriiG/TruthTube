import Foundation

public enum TruthTubeRiskLevel: String, Sendable {
    case warning
    case possibleAI
    case clear
}

public struct TruthTubeAnalysisResult: Equatable, Sendable {
    public let riskLevel: TruthTubeRiskLevel
    public let symbol: String
    public let label: String
    public let title: String
    public let reason: String?
    public let recommendation: String?

    public init(
        riskLevel: TruthTubeRiskLevel,
        symbol: String,
        label: String,
        title: String,
        reason: String? = nil,
        recommendation: String? = nil
    ) {
        self.riskLevel = riskLevel
        self.symbol = symbol
        self.label = label
        self.title = title
        self.reason = reason
        self.recommendation = recommendation
    }

    public var formattedMessage: String {
        var lines = [
            "\(symbol) \(label)",
            "",
            "Video Title🎥: \(title)"
        ]
        if let reason { lines.append("Reason🔍: \(reason)") }
        if let recommendation { lines.append("Recommendation💡: \(recommendation)") }
        return lines.joined(separator: "\n")
    }
}

public struct TruthTubeAnalyzer: Sendable {
    public static let shared = TruthTubeAnalyzer()

    private let fakeWords: [String]
    private let aiWords: [String]

    public init(
        fakeWords: [String] = [
            "deepfake", "fake", "scam", "hoax", "clickbait",
            "exposed", "banned", "hidden truth", "miracle cure", "100% real"
        ],
        aiWords: [String] = [
            "ai", "chatgpt", "generated", "midjourney", "synthetic",
            "voice clone", "ai voice", "ai image", "ai video",
            "artificial intelligence"
        ]
    ) {
        self.fakeWords = fakeWords
        self.aiWords = aiWords
    }

    public func analyze(title: String) -> TruthTubeAnalysisResult {
        let lowerTitle = title.lowercased()

        if let word = fakeWords.first(where: { lowerTitle.contains($0) }) {
            return TruthTubeAnalysisResult(
                riskLevel: .warning,
                symbol: "🔴",
                label: "Potential Fake / Clickbait",
                title: title,
                reason: "Detected keyword: \"\(word)\"",
                recommendation: "Verify the source before sharing."
            )
        }

        if let word = aiWords.first(where: { lowerTitle.contains($0) }) {
            return TruthTubeAnalysisResult(
                riskLevel: .possibleAI,
                symbol: "🟡",
                label: "Possible AI Generated Content",
                title: title,
                reason: "Detected keyword: \"\(word)\"",
                recommendation: "This content may contain AI-generated media."
            )
        }

        return TruthTubeAnalysisResult(
            riskLevel: .clear,
            symbol: "🟢",
            label: "No Obvious Warning",
            title: title
        )
    }
}
