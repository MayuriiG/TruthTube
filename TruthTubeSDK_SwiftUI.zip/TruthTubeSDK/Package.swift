// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TruthTubeSDK",
    platforms: [
        .iOS(.v15),
        .macOS(.v12)
    ],
    products: [
        .library(name: "TruthTubeSDK", targets: ["TruthTubeSDK"])
    ],
    targets: [
        .target(name: "TruthTubeSDK"),
        .testTarget(name: "TruthTubeSDKTests", dependencies: ["TruthTubeSDK"])
    ]
)
