import XCTest
@testable import TruthTubeSDK

final class TruthTubeSDKTests: XCTestCase {
    func testFakeKeyword() {
        let result = TruthTubeAnalyzer.shared.analyze(title: "This is a DEEPFAKE video")
        XCTAssertEqual(result.riskLevel, .warning)
        XCTAssertTrue(result.reason?.contains("deepfake") == true)
    }

    func testAIKeyword() {
        let result = TruthTubeAnalyzer.shared.analyze(title: "Made with ChatGPT")
        XCTAssertEqual(result.riskLevel, .possibleAI)
    }

    func testClearTitle() {
        let result = TruthTubeAnalyzer.shared.analyze(title: "SwiftUI Tutorial")
        XCTAssertEqual(result.riskLevel, .clear)
    }
}
